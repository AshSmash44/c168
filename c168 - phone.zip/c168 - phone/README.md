# PRO-C168-Boilerplate
### Download the model from here : https://sketchfab.com/3d-models/pizza-35d8c71791944a6c9f2082a1ad82827d
